package org.gradle.wrapper;

import java.io.IOException;
import java.io.InputStream;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.security.MessageDigest;
import java.time.Duration;
import java.util.HexFormat;
import java.util.Properties;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

/** Small self-contained bootstrapper for this repository's pinned Gradle distribution. */
public final class GradleWrapperMain {
    private static final Pattern HASH = Pattern.compile("(?i)\\b([a-f0-9]{64})\\b");
    private GradleWrapperMain() {}

    public static void main(String[] args) throws Exception {
        Path project = Path.of("").toAbsolutePath().normalize();
        Path propertiesFile = project.resolve("gradle/wrapper/gradle-wrapper.properties");
        if (!Files.isRegularFile(propertiesFile)) throw new IOException("Não encontrei gradle/wrapper/gradle-wrapper.properties.");
        Properties properties = new Properties();
        try (InputStream in = Files.newInputStream(propertiesFile)) { properties.load(in); }
        String url = properties.getProperty("distributionUrl", "").trim();
        if (!url.startsWith("https://")) throw new IOException("A URL do Gradle deve usar HTTPS.");
        URI distribution = URI.create(url);
        String archiveName = Path.of(distribution.getPath()).getFileName().toString();
        if (!archiveName.endsWith(".zip")) throw new IOException("A distribuição do Gradle não aponta para um ZIP.");
        String folderName = archiveName.substring(0, archiveName.length() - 4);
        String gradleHomeName = folderName.replaceFirst("-(bin|all)$", "");
        String userHome = System.getenv("GRADLE_USER_HOME");
        if (userHome == null || userHome.isBlank()) userHome = System.getProperty("user.home") + "/.gradle";
        Path cache = Path.of(userHome).resolve("wrapper/dists").resolve(folderName).resolve("radar-bootstrap");
        Path gradleHome = cache.resolve(gradleHomeName);
        boolean windows = System.getProperty("os.name", "").toLowerCase().contains("win");
        Path executable = gradleHome.resolve(windows ? "bin/gradle.bat" : "bin/gradle");

        if (!Files.isRegularFile(executable)) {
            Files.createDirectories(cache);
            Path archive = cache.resolve(archiveName + ".part");
            Path checksumFile = cache.resolve(archiveName + ".sha256.part");
            Files.deleteIfExists(archive);
            Files.deleteIfExists(checksumFile);
            HttpClient client = HttpClient.newBuilder()
                .followRedirects(HttpClient.Redirect.NORMAL)
                .connectTimeout(Duration.ofSeconds(30))
                .build();
            download(client, distribution, archive);
            download(client, URI.create(url + ".sha256"), checksumFile);
            String checksumText = Files.readString(checksumFile, StandardCharsets.UTF_8);
            Matcher matcher = HASH.matcher(checksumText);
            if (!matcher.find()) throw new IOException("Não foi possível ler o SHA-256 oficial da distribuição Gradle.");
            String expected = matcher.group(1).toLowerCase();
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            try (InputStream zipInput = Files.newInputStream(archive)) {
                byte[] buffer = new byte[64 * 1024];
                int count;
                while ((count = zipInput.read(buffer)) >= 0) digest.update(buffer, 0, count);
            }
            String actual = HexFormat.of().formatHex(digest.digest());
            if (!expected.equals(actual)) throw new IOException("O SHA-256 da distribuição Gradle não confere; arquivo descartado.");
            Path staging = cache.resolve("extracting");
            deleteTree(staging);
            Files.createDirectories(staging);
            unzipSafely(archive, staging);
            Path extracted = staging.resolve(gradleHomeName);
            if (!Files.isDirectory(extracted)) throw new IOException("Estrutura inesperada no ZIP do Gradle.");
            deleteTree(gradleHome);
            move(extracted, gradleHome);
            deleteTree(staging);
            Files.deleteIfExists(archive);
            Files.deleteIfExists(checksumFile);
        }

        ProcessBuilder builder = windows
            ? new ProcessBuilder(commandWithWindows(executable, args))
            : new ProcessBuilder(command(executable, args));
        builder.directory(project.toFile()).inheritIO();
        int exit = builder.start().waitFor();
        System.exit(exit);
    }

    private static void download(HttpClient client, URI uri, Path target) throws Exception {
        HttpRequest request = HttpRequest.newBuilder(uri).timeout(Duration.ofMinutes(10)).GET().build();
        HttpResponse<Path> response = client.send(request, HttpResponse.BodyHandlers.ofFile(target));
        if (response.statusCode() < 200 || response.statusCode() >= 300) {
            throw new IOException("Download do Gradle falhou: HTTP " + response.statusCode() + " em " + uri);
        }
    }

    private static void unzipSafely(Path archive, Path destination) throws IOException {
        try (ZipInputStream zip = new ZipInputStream(Files.newInputStream(archive))) {
            ZipEntry entry;
            while ((entry = zip.getNextEntry()) != null) {
                Path output = destination.resolve(entry.getName()).normalize();
                if (!output.startsWith(destination)) throw new IOException("Entrada ZIP fora do diretório permitido.");
                if (entry.isDirectory()) Files.createDirectories(output);
                else {
                    Files.createDirectories(output.getParent());
                    Files.copy(zip, output, StandardCopyOption.REPLACE_EXISTING);
                }
                zip.closeEntry();
            }
        }
    }

    private static java.util.List<String> command(Path executable, String[] args) {
        java.util.List<String> result = new java.util.ArrayList<>();
        result.add("/bin/sh");
        result.add(executable.toString());
        java.util.Collections.addAll(result, args);
        return result;
    }

    private static java.util.List<String> commandWithWindows(Path executable, String[] args) {
        java.util.List<String> result = new java.util.ArrayList<>();
        result.add("cmd.exe"); result.add("/c"); result.add(executable.toString());
        java.util.Collections.addAll(result, args);
        return result;
    }

    private static void move(Path source, Path destination) throws IOException {
        try { Files.move(source, destination, StandardCopyOption.ATOMIC_MOVE); }
        catch (IOException ex) { Files.move(source, destination, StandardCopyOption.REPLACE_EXISTING); }
    }

    private static void deleteTree(Path root) throws IOException {
        if (!Files.exists(root)) return;
        try (var paths = Files.walk(root)) {
            for (Path path : paths.sorted(java.util.Comparator.reverseOrder()).toList()) Files.deleteIfExists(path);
        }
    }
}
